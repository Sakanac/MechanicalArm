# encoding:utf-8
import cv2


cap = cv2.VideoCapture(-1) # 打开摄像头 
while (1):

  ret, frame = cap.read()
  frame = cv2.flip(frame, 1) # 摄像头是和人对立的，将图像左右调换回来正常显示

  cv2.imshow("capture", frame) # 生成摄像头窗口
  cv2.imwrite("img.jpg", frame) # 保存路径
  break
cap.release()
cv2.destroyAllWindows()


face_cascade = cv2.CascadeClassifier('/home/pi/Downloads/haarcascade_frontalface_default.xml')
# 读取图像
img = cv2.resize(cv2.imread('img.jpg'),(1024,768))
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # 转为灰度图


# 检测脸部
faces = face_cascade.detectMultiScale(gray,
                            scaleFactor=1.1,
                            minNeighbors=5,
                            minSize=(30, 30),
                            flags=cv2.CASCADE_SCALE_IMAGE)
print('Detected ', len(faces), " face")


# 标记位置
for (x, y, w, h) in faces:
    img = cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 1)
    # cv2.circle(img, (int((x + x + w) / 2), int((y + y + h) / 2)), int(w / 2), (0, 255, 0), 1)
    roi_gray = gray[y: y + h, x: x + w]
    roi_color = img[y: y + h, x: x + w]




label = 'Result: Detected ' + str(len(faces)) +" faces !"
cv2.putText(img, label, (10, 20),
            cv2.FONT_HERSHEY_SCRIPT_COMPLEX,
            0.8, (0, 0, 0), 1)

# 显示图像
cv2.imshow('img', img)
cv2.waitKey(0)
cv2.destroyAllWindows()