import multiprocessing as mp
import cv2
import dlib
 
def detect_face(frame,value):
    img = frame
    dets = detector(img, 1)
    for index, face in enumerate(dets):
 
        left = face.left()
        top = face.top()
        right = face.right()
        bottom = face.bottom()
 
#Except error           
    try:
        value[:] = [left,top,right,bottom]
    except UnboundLocalError:
        value[:] = [0,0,0,0]
 
def draw_line(img,box):
    
    left = box[0]
    top = box[1]
    right = box[2]
    bottom = box[3]
    
#Locate face
    cv2.rectangle(img, (left*2, top*2), (right*2, bottom*2), (255, 0, 0), 1)
    return img
    
if __name__=='__main__':
 
#initial detector and cap
    detector = dlib.get_frontal_face_detector() #get classifier for face detection
    cap = cv2.VideoCapture(-1)  #Turn on the camera
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
    cap.set(3,320)
    cap.set(4,240)
 
#initial boxes
    box1 = mp.Array('i',[0,0,0,0])
    box2 = mp.Array('i',[0,0,0,0])
    
#initial Windowbox
    cv2.namedWindow('success', cv2.WINDOW_AUTOSIZE)
    
#initial frames and processes
    ret, frame11 = cap.read()
    img11 = cv2.resize(frame11,(160,120))
    res1 = mp.Process(target=detect_face,args=(img11,box1))
    res1.start()

#Resize img
    ret, frame21 = cap.read()
    img21 = cv2.resize(frame21,(160,120))
    res2 = mp.Process(target=detect_face,args=(img21,box2))
    res2.start()
    
    while(cap.isOpened()):
#process 1
        if (res1.is_alive()):
            ret, frame12 = cap.read()
            frame12 = cv2.flip(frame12, 1)
            cv2.imshow('success',draw_line(frame12,box1))            
#            pass           
        else:
            ret, frame11 = cap.read()
            frame11 = cv2.flip(frame11, 1)
            cv2.imshow('success',draw_line(frame11,box1))
            img11 = cv2.resize(frame11,(160,120))           
            res1 = mp.Process(target=detect_face,args=(img11,box1))
            res1.start()
            
#process 2
        if (res2.is_alive()):
            ret, frame22 = cap.read()
            frame22 = cv2.flip(frame22, 1)
            cv2.imshow('success',draw_line(frame22,box2))  
#            pass          
        else:
            ret, frame21 = cap.read()
            frame21 = cv2.flip(frame21, 1)
            cv2.imshow('success',draw_line(frame21,box2))
            img21 = cv2.resize(frame21,(160,120)) 
            res2 = mp.Process(target=detect_face,args=(img21,box2))
            res2.start()
 
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
            
    cv2.destroyAllWindows()
    cap.release()
    print('END')